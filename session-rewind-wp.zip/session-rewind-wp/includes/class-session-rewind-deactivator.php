<?php
/**
 * Fired during plugin deactivation.
 *
 * @since      1.0.0
 * @package    Session_Rewind
 * @subpackage Session_Rewind/includes
 * @author     Session Rewind <yair@sessionrewind.com>
 */
class Session_Rewind_Deactivator {

	public static function deactivate() {

	}

}
